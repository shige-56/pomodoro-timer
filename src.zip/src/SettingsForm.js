import React from 'react';

function SettingsForm({ workTime, setWorkTime, shortBreak, setShortBreak, longBreak, setLongBreak, maxCycles, setMaxCycles, isActive }) {

  const handleInputChange = (e, setter) => {
    const value = e.target.value;
    // 値が空の場合は空文字のままにし、バリデーションで固定値を入力しない
    if (value === '') {
      setter('');
    } else if (!isNaN(value) && parseInt(value, 10) > 0) {
      setter(parseInt(value, 10));
    }
  };

  return (
    <div className="settings-container">
      <div className="setting-group">
        <label>作業時間 (分)</label>
        <input
          type="number"
          value={workTime ? workTime / 60 : ''}  // 値が空の場合は空文字を表示
          onChange={(e) => handleInputChange(e, (val) => setWorkTime(val * 60))}
          disabled={isActive}  // タイマーがアクティブな場合は入力不可
          className={isActive ? 'input-disabled' : ''}  // 無効な時はスタイルを変更
        />
      </div>
      <div className="setting-group">
        <label>短い休憩 (分)</label>
        <input
          type="number"
          value={shortBreak ? shortBreak / 60 : ''}  // 値が空の場合は空文字を表示
          onChange={(e) => handleInputChange(e, (val) => setShortBreak(val * 60))}
          disabled={isActive}  // タイマーがアクティブな場合は入力不可
          className={isActive ? 'input-disabled' : ''}  // 無効な時はスタイルを変更
        />
      </div>
      <div className="setting-group">
        <label>長い休憩 (分)</label>
        <input
          type="number"
          value={longBreak ? longBreak / 60 : ''}  // 値が空の場合は空文字を表示
          onChange={(e) => handleInputChange(e, (val) => setLongBreak(val * 60))}
          disabled={isActive}  // タイマーがアクティブな場合は入力不可
          className={isActive ? 'input-disabled' : ''}  // 無効な時はスタイルを変更
        />
      </div>
      <div className="setting-group">
        <label>ポモドロー回数</label>
        <input
          type="number"
          value={maxCycles || ''}  // 値が空の場合は空文字を表示
          onChange={(e) => handleInputChange(e, setMaxCycles)}
          disabled={isActive}  // タイマーがアクティブな場合は入力不可
          className={isActive ? 'input-disabled' : ''}  // 無効な時はスタイルを変更
        />
      </div>
    </div>
  );
}

export default SettingsForm;
